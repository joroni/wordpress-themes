<?php

/**
 * Home Page.
 *
 * @category   Genesis_Sandbox
 * @package    Templates
 * @subpackage Home
 * @author     Travis Smith and Jonathan Perez, for Surefire Themes
 * @license    http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link       http://wpsmith.net/
 * @since      1.1.0
 */

remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 ) ;

add_action( 'genesis_before', 'custom_mobile_nav', 3 );
add_action( 'genesis_before', 'genesis_header_markup_open', 5 );
add_action( 'genesis_before', 'add_mobile_menu', 7 );
add_action( 'genesis_before', 'genesis_do_header', 11 );
add_action( 'genesis_before', 'custom_header_menu', 13 );
add_action( 'genesis_before', 'genesis_header_markup_close', 15 );

remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'render_home_page' );

// remove_action( 'genesis_sidebar', 'genesis_sidebar_markup_open', 5 );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
// remove_action( 'genesis_sidebar', 'genesis_sidebar_markup_close', 15 ) ;

// remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
// add_action( 'genesis_sidebar', 'genesis_sidebar_markup_open', 5 );
add_action( 'genesis_sidebar', 'custom_sidebar', 9);
// add_action( 'genesis_sidebar', 'genesis_sidebar_markup_close', 15 ) ;

// add_filter( 'genesis_sidebar', 'custom_sidebar' );


add_filter( 'excerpt_length', 'my_excerpt_length' );
add_filter( 'excerpt_more', 'my_excerpt_more' );

remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5);
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 ) ;

add_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
add_action( 'genesis_footer', 'custom_broadbent_footer', 7 );
add_action( 'genesis_footer', 'genesis_do_footer', 9 );
add_action( 'genesis_footer', 'genesis_footer_markup_close', 15);



function my_excerpt_length($length) {
        return 15;
}
function my_excerpt_more( $more ) {
        return '... <a class="read-more" href="' . get_permalink( get_the_ID() ) . '">Read More</a>';
}

function custom_header_menu() {
        ?>

        <div class="right-section">
                <ul>
                        <li>
                                <a href="#">Home</a> |
                        </li>
                        <li>
                                <a href="#">About</a> |
                        </li>
                        <li>
                                <a href="#">Contact</a>
                        </li>
                </ul>
                <div class="clear"></div>
                <div class="icons">
                        <a href="#"><img src="/wp-content/themes/forkandkniv/images/facebook-icon.png" alt="Facebook Icon"></a>
                        <a href="#"><img src="/wp-content/themes/forkandkniv/images/twitter-icon.png" alt="Twitter Icon"></a>
                        <a href="#"><img src="/wp-content/themes/forkandkniv/images/google-plus-icon-small.png" alt="Google Plus Icon"></a>
                        <a href="#"><img src="/wp-content/themes/forkandkniv/images/instagram-icon-small.png" alt="Instagram Icon"></a>
                        <a href="#"><img src="/wp-content/themes/forkandkniv/images/pintrest-icon.png" alt="Pinterest Icon"></a>
                </div>
        </div>

        <?php
}

add_action( 'get_header', 'gs_home_helper' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function gs_home_helper() {

        if ( is_active_sidebar( 'home-top' ) || is_active_sidebar( 'home-left' ) || is_active_sidebar( 'home-right' ) || is_active_sidebar( 'home-bottom' ) ) {

                remove_action( 'genesis_loop', 'genesis_do_loop' );
                add_action( 'genesis_loop', 'gs_home_widgets' );

                /** Force Full Width */
                add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
                add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

        }
}

/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function gs_home_widgets() {

        genesis_widget_area(
                'home-top',
                array( 'before' => '<div id="home-top" class="home-widget widget-area">', )
        );

        echo '<div id="home-middle">';
        genesis_widget_area(
                'home-left',
                array(
                        'before' => '<div id="home-left" class="first one-half"><div class="home-widget widget-area">',
                        'after' => '</div></div><!-- end #home-left -->',
                )
        );

        genesis_widget_area(
                'home-right',
                array(
                        'before' => '<div id="home-right" class="one-half"><div class="home-widget widget-area">',
                        'after' => '</div></div><!-- end #home-right -->',
                )
        );
        echo '</div>';


        genesis_widget_area(
                'home-bottom',
                array(
                        'before' => '<div id="home-bottom"><div class="home-widget widget-area">',
                        'after' => '</div></div><!-- end #home-left -->',
                )
        );
}

function render_home_page() {
        $post_count = 0;
        $left_col = array();
        $right_col = array();
        $featured_post = '';

        ?>

        <?php

        if( have_posts() ) {
                while( have_posts() ) : the_post() ;
                        if( $post_count === 0 ) {
                                show_featured_post();
                        }

                        $post_count++;
                endwhile;
        }

        ?>
        <div class="left-col">
        <?php

        //Menu
        show_weekly_menu();

        $post_count = 0;
        if( have_posts() ) {
                while( have_posts() ) : the_post() ;
                        if( $post_count != 0 && $post_count % 2 != 0 ) {
                                show_regular_post();
                        }
                        $post_count++;
                endwhile;
        }

        ?>
        </div>
        <div class="right-col">
        <?php

        $post_count = 0;
        if( have_posts() ) {
                while( have_posts() ) : the_post() ;
                        if( $post_count != 0 && $post_count % 2 === 0 ) {
                                show_regular_post();
                        }

                        $post_count++;
                endwhile;
        }

        ?>
        </div>
        <?php
}

function show_weekly_menu() {
        ?>
        <div class="weekly-menu">
                <img src="/wp-content/themes/forkandkniv/images/blue-background.jpg" alt="Fancy Dinner Set">
                <div class="menu-title">
                        Weekly Menu
                </div>
                <div class="menu-content">
                        <?php get_menu_items() ?>
                </div>
        </div>
        <?php
}

function get_menu_items() {
        $args = array('category_name' => 'weekly-menu', 'posts_per_page' => '3' );
        $query = new WP_Query( $args );

        while( $query->have_posts() ) {
                $query->the_post();

                ?>
                <div class="menu-item">
                        <div class="title">
                                <?php the_title(); ?>
                        </div>
                        <div class="content">
                                <?php echo '<p>' . substr( get_the_content(), 0, 70 ) . '...</p>' ?>
                                <a href="<?php the_permalink() ?>" class="view-recipe">View Recipe</a>
                        </div>
                </div>
                <?php
        }

        wp_reset_postdata();
}

function show_featured_post() {
        ?>
        <div class="featured-post">
                <?php if( has_post_thumbnail() ) { ?>
                        <div class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('full-size'); ?></a>
                        </div>
                <?php } ?>

                <div class="post-content">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title() ?></a></h2>
                        <?php echo '<p>' . substr( get_the_content(), 0, 350 ) . '... <a href="' . get_permalink() . '">[Read More]</a>' . '</p>' ?>
                        <?php echo do_shortcode('[social_share]'); ?>
                </div>
        </div>
        <?php
}

function show_regular_post() {
        ?>
        <div class="normal-post">
                <?php if(has_post_thumbnail() ) { ?>
                        <div class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
                        </div>
                <?php } ?>

                <div class="post-content">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title() ?></a></h2>
                        <?php the_excerpt() ?>
                </div>
        </div>
        <?php
}

remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_after_header', 'custom_navigation' );

function custom_navigation() {
        $menu_id = get_menu_id();

        $nav_items = wp_get_nav_menu_items( $menu_id );

        ?>

        <div class="wrap">
                <div class="nav-menu">
                        <ul class='full-nav'>
                        <?php
                        foreach( $nav_items as $key=>$nav ) {
                                echo "<li class='nav-item'><a href='" . $nav->url . "'>" . $nav->title . "</a>";
                                if(!last_element($nav_items, $key)) {
                                        echo '<span class="nav-seperator">|</span>';
                                }
                                echo "</li>";
                        }
                        ?>
                        </ul>
                        <div class='clear'></div>
                </div>
        </div>

        <?php
}

function custom_mobile_nav() {
        $menu_id = get_menu_id();

        $nav_items = wp_get_nav_menu_items( $menu_id );

        ?>
        <nav class="fixed-mobile-nav">
                <div class="title">
                        NAVIGATION
                </div>
                <?php
                foreach( $nav_items as $nav ) {
                        echo "<a class='nav-item' href='" . $nav->url . "'>" . $nav->title . "</a>";
                }
                ?>
        </nav>
        <?php
}

function last_element($array, $key) {
        end($array);
        return $key === key($array);
}

function get_menu_id() {
        $menu_slug = "Primary Nav";
        $locations = get_nav_menu_locations();

        if( isset( $locations['primary'] ) ) {
                return $locations['primary'];
        }

        return null;
}

function add_mobile_menu() {
        ?><a href="#" class='mobile-menu-toggle'>Menu</a><?php
}

function custom_broadbent_footer() {
        ?>
        <div id="main-footer">
                <div id="footer-widgets">
                        <div id="other-site-feeds">
                                <div class="column">
                                        <div id="other-site-feeds-left"><div class="footer-column first"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsLeft1' ); ?></div></div></div>
                                        <div id="other-site-feeds-middle"><div class="footer-column"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsMiddle1' ); ?></div></div></div>
                                        <div id="other-site-feeds-right"><div class="footer-column last"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsRight1' ); ?></div></div></div>

                                        <div class="clear"></div>
                                </div>

                                <div class="column">
                                        <div id="other-site-feeds-left"><div class="footer-column first"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsLeft2' ); ?></div></div></div>
                                        <div id="other-site-feeds-middle"><div class="footer-column"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsMiddle2' ); ?></div></div></div>
                                        <div id="other-site-feeds-right"><div class="footer-column last"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsRight2' ); ?></div></div></div>

                                        <div class="clear"></div>
                                </div>

                                <div class="column">
                                        <div id="other-site-feeds-left"><div class="footer-column first"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsLeft3' ); ?></div></div></div>
                                        <div id="other-site-feeds-middle"><div class="footer-column"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsMiddle3' ); ?></div></div></div>
                                        <div id="other-site-feeds-right"><div class="footer-column last"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsRight3' ); ?></div></div></div>

                                        <div class="clear"></div>
                                </div>

                                <div class="column">
                                        <div id="other-site-feeds-left"><div class="footer-column first"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsLeft4' ); ?></div></div></div>
                                        <div id="other-site-feeds-middle"><div class="footer-column"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsMiddle4' ); ?></div></div></div>
                                        <div id="other-site-feeds-right"><div class="footer-column last"><div class="footer-widget"><?php dynamic_sidebar( 'OtherSiteFeedsRight4' ); ?></div></div></div>
                                </div>
                        </div>

                        <div class="clear"></div>
                </div>
        </div>
        <?php
}

function custom_sidebar() {
        ?>
        <div class="choose-category">
                <div class="title">
                        Choose
                </div>
                <div class='inner'>
                        <a class="fish" href="#"></a>
                        <a class="meat" href="#"></a>
                        <a class="chicken" href="#"></a>
                        <a class="swedish" href="#"></a>
                        <a class="roast" href="#"></a>
                        <div class="clear"></div>
                </div>
        </div>
        <?php
        dynamic_sidebar( 'custom-sidebar' );
}

genesis();