<?php


remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_footer', 'custom_footer' );

function custom_footer() {
	?>
	<div class="footer-top">
		<div class="one-half first">
			<a href="<?php echo home_url(); ?>" class='footer-logo'></a>
		</div>
		<div class="one-half">
			<div class="social-wrap">
				<ul>
					<li>
						<a href="https://www.facebook.com/craig.gore.9" target="_blank" class='social facebook'></a>
					</li>
					<li>
						<a href="https://twitter.com/Cgorepf" target="_blank" class='social twitter'></a>
					</li>
					<li>
						<a href="https://plus.google.com/107732337708201113738/posts" target="_blank" class='social googleplus'></a>
					</li>
					<li>
						<a href="http://au.linkedin.com/pub/dir/Craig/Gore" target="_blank" class='social linkedin'></a>
					</li>
					<li>
						<a href="http://www.youtube.com/user/youidiotable" target="_blank" class='social youtube'></a>
					</li>
				</ul>
			</div>
		</div>
		<div style="clear: both;"></div>
	</div>

	<div class="footer-bottom">
		<p>
			Copyright &copy; <?php echo date('Y'); ?> Craig K. Gore. All Rights Reserved.
		</p>
	</div>
	<?php
}

?>