<?php

$result = array( "status" => "1" );

echo json_encode( $result );